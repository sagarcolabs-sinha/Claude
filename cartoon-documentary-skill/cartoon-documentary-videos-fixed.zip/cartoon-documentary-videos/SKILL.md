---
name: "cartoon-documentary-videos"
description: "Write and produce animated 2D cartoon documentary videos on any topic — finance, war, ancient humans, animals, science — script, characters, voice, edit, render in code."
---

# Cartoon Documentary Videos

Turn any title or topic into a finished, fully animated 2D cartoon documentary: an engaging, fact-checked script; characters, sets and props drawn **in code** (no image generators); a voiceover; camera work, transitions, text cards, sound design; and a rendered MP4.

The look: Cyanide-&-Happiness-meets-editorial-cartoon. Big round heads, dot eyes, bean bodies, stick limbs, thick dark outlines, flat colours with soft lamp lighting, dark vignettes, a handwritten font, and a calm documentary narrator interrupted by short deadpan character skits.

Works for every niche. The user brings a title or topic (and optionally a length, audience, narrator voice). If they give only a title, everything else is your call.

---

## 0. The rules that are never broken

1. **Every script is written from scratch.** Never reuse a script, a hook or a comparison set from an earlier video, and never copy wording from this skill's examples. You cannot see other people's scripts, so variety comes from fresh research and a freshly rolled fingerprint: follow Section 3 ("The uniqueness system") on every single script. The example lines in this skill show *shapes*, never words to reuse.
2. **Fact-check every claim** against named, reliable sources found by searching *before* writing. Facts about the present (who holds a role, prices, latest numbers) are always searched. If a fact can't be confirmed, cut it or say plainly that it's disputed. Put "Figures as of [date], from [sources]" in the description.
3. **YouTube-safe by design** (monetisation + community guidelines):
   - Real people appear only as simple caricatures with a name label. **Never invent quotes for real people.** Real quotes are short, exact and attributed. Invented skit lines go to unnamed or generic characters ("a banker", "a soldier", "a cave kid").
   - No gore, no graphic injury. War, crime and predation are implied: smoke, a dropped helmet, a cut away, an empty chair.
   - No brand logos, copyrighted characters or real artwork. Use generic shapes and plain names ("COLA" on the bottle, an apple with a crown for a tech giant).
   - No hate, harassment or medical/financial "advice". Present facts and both sides. Stay neutral on politics.
   - Make the value original: your own script, your own drawings, your own analysis.
4. **Numbers in narration are written the way the narrator says them** ("eighteen ninety-nine", "four hundred billion dollars", "nine one one"). On-screen text uses digits.
5. **Default call to action** goes right after the cold open, in the narrator's voice: *"Before we go deep into today's [video/story/case], take a second to like this video and subscribe if you haven't. Let's get into it."* Use it unless the user gives their own line or says not to.

---

## 1. Workflow (do it all, end to end)

1. **Setup** (Section 9): install pycairo and the fonts, and copy `engine.py` (it ships next to this file) into the working folder.
2. **Research** the topic hard: 8–20 searches, named sources, exact numbers and dates. For any story with a "latest" part, search for the latest.
3. **Creative fingerprint** (Section 3): roll it and write it at the top of your working notes.
4. **Write the script** (Sections 2–4) in production format (Section 4). Then run the uniqueness check and the fact check.
5. **Voice** (Section 7): narrator plus character voices. Get the audio into the workspace and measure its timing.
6. **Plan the edit**: for each script beat, a scene, a shot list, on-screen events keyed to narration times, and transitions (Section 6).
7. **Build the scenes in code** with the engine (Section 5). Render stills and contact sheets, look at them, fix them.
8. **Render**: chapters in parallel for long videos, concatenate, mix the music, SFX and voices, and mux to MP4.
9. **QA** (Section 8), then deliver: the MP4, the script, a title, a description with chapters and sources, and a thumbnail idea.

If the user only wants the script, stop after step 4. If they only want a short test, keep the same pipeline with 3–5 scenes.

---

## 2. How to write the script (any niche)

### 2.1 The measurable house style
- **Pace:** 150–165 spoken words per minute. A 15-minute video is about 2,300 words.
- **Short sentences:** the average is about 8 words and the median about 7. Mix in fragments. Use a long sentence only to build up before a short punch.
- **Chapters:** 6–9 named chapters of 1.5–3 minutes each. The chapter names become the YouTube chapters.
- **Skits:** a 2–4 line character skit every 20–40 seconds.
- **Text cards:** a black card with the narrator's line typed on screen every 30–60 seconds, on the lines that hit hardest.
- **Plain English** a 12-year-old follows. Explain every technical word the first time it appears, in a few words, with a picture-able comparison.

### 2.2 The spine (adapt the order to the story; never fill it in mechanically)
1. **Cold open, 20–45 s.** Drop the viewer into the most surprising true moment. Pair a concrete scene or shocking fact with the thing that doesn't add up (the contradiction), then ask the one question the video answers.
2. **Mini-skit** that turns the shock into a laugh or a gasp.
3. **CTA line** (Rule 5).
4. **Stamp the time and place** and start the story at its real beginning.
5. **Backstory:** who these people (or animals, or empires) are and what they wanted.
6. **Mechanism chapters:** how it actually works, one idea per chapter, each with a comparison to everyday life.
7. **The turn:** the moment the obvious explanation collapses and the real one appears.
8. **Where it stands now / who it touches:** connect it to the viewer's life, money, body, history or future.
9. **The answer plus a callback:** answer the title question in one or two sentences, return to the cold-open image changed, and end on one line that lingers. No "thanks for watching".

### 2.3 The engagement tools (use them; invent your own wording every time)
- **Contradiction hooks:** state the fact, then the reason it shouldn't be possible.
- **Human-scale numbers:** every big number gets converted into something the viewer can feel. Per hour, per person, per heartbeat; the price of a familiar object; how many football fields, buses or lifetimes. Do the math and check it.
- **Everyday comparisons:** explain a hard mechanism with a familiar situation (a kitchen, a classroom, a parking lot, a group chat). Pick comparison worlds that fit the audience, and never reuse the same one twice in a video.
- **Open loops:** plant a detail and promise it will come back. Pay it off later with a twist. Keep at least one loop open at all times until the last chapter.
- **The turn line:** each new beat starts with a short line that pivots. Write a new one every time; never use a stock phrase (Section 3.3).
- **Clock or calendar spine** for event stories: tell the climax by timestamps or dates. Each beat starts with the time.
- **Second person, sparingly:** "If you've ever…", "Picture your…". Once or twice per chapter at most.
- **Specific over general:** names, places, dates and exact figures. The more specific, the more unique and the more trusted.
- **Fairness beat:** give the strongest point of the other side at least once. It builds trust and keeps the video safe.
- **Skits restate the point as a joke.** Deadpan, 2–4 lines, a recognisable everyday reaction ("Wait, how much?"). A skit never introduces a new fact the narrator hasn't stated, and never puts invented words in a real person's mouth.

### 2.4 Niche adaptation (examples of what changes; keep the spine)
| Niche | Typical cold open | Skit cast | Human-scale moves | Signature visuals |
|---|---|---|---|---|
| Finance / business | a number that broke a record | traders, a clerk, a confused saver | per hour, per person, prices of everyday things | trading floors, offices, documents, chart boards |
| War / military history | the night before, one soldier's moment | generic soldiers, a radio operator, a cook | distances in walking days, ages of soldiers | trenches, maps with arrows, tents, rain, searchlights (no gore) |
| Ancient humans / prehistory | a find in the ground, then "who left it" | a cave family, an elder, a curious kid | generations, "if all history were one day" | fires, caves, mammoths, footprints, a scientist's lab in the present |
| Animals / nature | an animal doing something impossible | the animals' inner voices, a ranger | speed vs a car, weight vs a fridge | sunsets, savanna, ocean layers, burrows |
| Science / space | an everyday thing that is secretly strange | lab coat scientists, a skeptic friend | scale jumps (grain of sand to planet) | labs, diagrams on chalkboards, planets |
| True crime (non-graphic) | the ordinary morning before | detectives, a clerk, a neighbour | timelines by the minute | offices, evidence boards, rainy streets |

---

## 3. The uniqueness system (mandatory for every script)

Two people may type the same title. Fresh research and a freshly rolled fingerprint keep their scripts from sharing sentences, hooks or comparison sets. Use all four layers below.

### 3.1 Roll a creative fingerprint first
Make a seed from the title, the current date and time, and a random number (`python3 -c "import random,time;print(random.randrange(10**9))"`). Use it to choose:
- **Entry point** (one of): a single person's moment; an object; a number; a place at a precise time; an ending first, then rewind; a mistake; a question asked by an ordinary person; the opposing side's view; a "day in the life"; a map; a letter or document; a sound.
- **Point-of-view lens:** the insider, the outsider, the victim or loser, the skeptic, the future looking back, the money, the object itself.
- **Structure variant:** chronological; reverse chronology; two timelines that meet; countdown; "five clues"; "myth vs record"; a three-act investigation.
- **Comparison worlds** (pick 3 that fit the audience and were not used in your last video): kitchens, sports, school, traffic, weddings, farming, video games, a group chat, a market, the gym, the post office, a family dinner, a road trip, a garden, a hospital waiting room, music bands, the weather, a phone battery…
- **Skit cast flavour:** dry office workers; nosy neighbours; a kid asking questions; animals' inner voices; time-travelling tourist; tired night-shift staff.
- **Ending type:** callback image; ironic echo of an early quote; open question that is still unresolved; "the number nobody puts on a thumbnail"; a quiet human detail.
- **Chapter-title style:** object names; time stamps; short phrases; questions.

Write the fingerprint in your notes and obey it. If the same user asks for the same topic again, re-roll and also change the entry point and the lens.

### 3.2 Write from the research, not from memory
Build each paragraph around specifics found in this video's research: names, dates, places, quotes, numbers. Generic sentences ("It changed everything") are what make scripts look alike. Aim for at least 4 concrete facts per minute.

### 3.3 Banned phrases (never use, in any form)
Generic AI and YouTube filler: "Let's dive in", "buckle up", "in a world where", "little did they know", "but here's the thing", "the rest is history", "game-changer", "it's not just X, it's Y", "fast forward to", "spoiler alert", "you won't believe", "this is where things get interesting", "the answer may surprise you", "what happened next", "stay tuned", "without further ado".

Never borrow another channel's catchphrases or signature lines either. Invent your own pivots each time. The only fixed sentence allowed is the CTA in Rule 5.

### 3.4 Self-check before you hand it over
- **Portable-sentence test:** any sentence that could sit unchanged in a different video on a different topic gets rewritten with a specific detail.
- **Opener variety:** no two chapters start with the same word or the same sentence shape. No more than two sentences in a row start with the same word, except on purpose for rhythm.
- **Comparison audit:** each comparison is used once; none comes from the examples in this skill.
- **Hook audit:** write 3 different cold opens and keep the strongest. Never keep the first one by default.

---

## 4. Script production format

Write the script in this format so the edit can be built straight from it:

```
TITLE: <title>                       FINGERPRINT: <seed + choices>
VOICES: NARRATOR=<voice>, <CHAR_A>=<voice>, ...

## CHAPTER 1 — <chapter name>                  [CARD: chapter title yes/no]
[SCENE 1.1 | <place, era, time of day> | mood: <warm/tense/...> | shots: wide → close on <x> → reaction]
NARRATOR: <spoken text, numbers as words>
  >> ON: tag "$400B" @ "four hundred billion"     (event keyed to a word)
  >> ON: calendar 1886→1959 during this line
SKIT — <GENERIC CHARACTER>: "<line>"
SKIT — <GENERIC CHARACTER>: "<line>"
CARD: "<the narrator line to type on black>"
NARRATOR: Before we go deep into today's video, take a second to like this video and subscribe if you haven't. Let's get into it.
[SCENE 1.2 | ...]   >> TRANSITION: zoom into the tag / whip / hard cut on beat
```

Then add: a title (35–55 characters; a news hook or contradiction plus curiosity, no clickbait that the video doesn't pay off), a description (two summary paragraphs, a question for the comments, chapter timestamps, "Figures as of…, from reporting by…"), and one thumbnail idea (one character, one object, one big number or word).

---

## 5. Visual style bible (how every frame is built)

### 5.1 Characters (`person()` in the engine)
- **Proportions:** the head is about 45% of the height. Small dot eyes, a small line mouth, a bean body and stick limbs, all with a thick ink outline (about 5 px at 1080p).
- **Identity comes from 1–2 features only:** hair shape and colour, glasses or sunglasses, beard, hat, outfit colour.
  - Real people get a lower-third name label the first time they appear.
  - Keep each character's look identical every time they return. Define them once in a `CAST` dict.
- **Costumes for any era:** `hat='helmet'` (soldiers), `robe=` (ancient people, monks, Romans), `style='wild'` + `beard='full'` (prehistoric), `tophat`, `crown`, `cowboy`, `hardhat`, `beret`, `hood`, `headband`. Add new hats or props as small functions in the same style.
- **Animals:** `animal()` gives dog, cat, wolf, lion, bear, horse, deer, cow, elephant and mammoth in the same style. For birds, fish, reptiles and insects, write a new function that follows the same rules: round head, dot eye, flat colour, ink outline, simple stick or blob limbs.
- **Always alive:**
  - They bob and tilt automatically.
  - Mouths move only while their voice line plays: `mouth=talking(tg, (start, end))`.
  - They blink: `blink=blinking(tg, seed)`.
  - They gesture on key words: raise an arm, point, nod or shake the head with `headrot`.
  - They walk in with `walk=1`.
  - They show mood with `mood='worried'|'happy'|'angry'|'shocked'`.

### 5.2 Sets
- **One fully lit set per story beat**, built in depth layers:
  - background `cam(c, 0.6–0.8)`: sky, walls, distant city, mountains
  - main layer `cam(c, 1.0)`: floor, furniture, characters, props
  - foreground `cam(c, 1.1–1.2)`: the counter edge, a character's shoulder, sandbags
  - Draw background rectangles bigger than the screen (for example `-400…W+400`) so camera moves never show an empty edge.
- **Lighting makes it look expensive.** Use mostly dim or night scenes with one warm light source (lamp, fire, neon, monitor) using `glow()`, plus `vignette()` and the film grain, which the engine adds automatically.
- **Mood colours:**
  - navy/charcoal: secrets, government, night
  - deep red: crisis, crash, danger
  - warm amber: homes, diners, the past
  - olive/khaki: war
  - earthy browns with firelight: prehistory
  - golden hour: nature
  - green glow: money/tech
- **Props carry the information:**
  - calendars for the year, wall clocks for the hour
  - documents with a highlighter swipe
  - pop-in tags for key numbers, stamps for verdicts
  - newspapers, maps with pins, coins, crates
  - charts drawn inside the scene (on a board, TV or wall), not on blank paper
- **Reuse sets** when the story returns somewhere, with small changes (a new date, a new whiteboard line). This gives continuity and saves time.
- **Ambient motion in every scene (1–3 of):** dust in light beams, steam, smoke, rain, snow, fire, flickering lamps, a passing car or bird, blinking window lights.

### 5.3 Text and graphics
- **Black text cards:** the narrator's line typed in sync, white handwritten font (Caveat), with an optional yellow second line for the punch. Use them for the hardest-hitting lines, and as breathers between scenes.
- **Chapter title cards:** a centred title on black for 1–1.5 s at each chapter start.
- **Lower labels:** "PLACE, YEAR" when a scene opens, and names of real people. Fade in over 0.5 s and out after about 2.5 s.
- **Pop-in tags and stamps** land exactly on the spoken word, with a pop or thud sound and a small camera shake.

---

## 6. Editing rules (camera, cuts, transitions)

- **Shots:** each scene has a shot list `[(t0, t1, (cx,cy,zoom) from, (cx,cy,zoom) to, easing)]`.
  - Each new entry is a hard cut to a new framing.
  - Typical grammar: establishing wide shot, then a push-in on the important object, then a closer shot of whoever talks, then a reaction shot.
  - Change framing every 1.5–4 s. In skits, cut on each speaker (over-the-shoulder style).
- **Every shot moves:** a slow pan and/or a 4–10% zoom with `smooth`. Never a frozen frame. Faster moves are for tension.
- **Depth:** the background moves slower than the foreground via the `cam(c, depth)` layers.
- **Shake:** add `(t, amplitude)` to `SHAKES` on impacts. 5–10 px for tags and pops, 20–30 px for stamps, crashes and explosions (implied).
- **Transitions:** most cuts are hard cuts that land on the voice beat or a sound effect. About once per chapter, use a motivated one:
  - **zoom-through:** `exit='zoom'` plus `zoom_shot()`. The camera dives into an object (a tag, a coin slot, a map pin, a window) and dissolves to black or a card.
  - **whip pan:** `exit='whip'` plus `whip_shot()`. A fast blurred sideways slam into the next place, with a whoosh.
  - **fade from black:** `enter='fade'`, after cards.
- **Cards** sit between scenes as breathers. A tiny slow zoom (1.00 → 1.06) keeps them alive.
- **Sync:** every visual event is keyed to a narration timestamp, never guessed.

---

## 7. Voice and sound

- **Narrator:** one calm, clear documentary voice with warm, steady pacing. Use the user's choice, or pick one from the TTS tool's library (for example search "documentary narrator").
  - **Character voices** are different from the narrator and from each other, one per skit role, kept the same all video.
- **Generating:**
  - Make the narration one chapter at a time, so each audio file maps to known script lines.
  - Keep the exact same voice and model for every chunk.
  - If the user is present, play them a short sample and confirm the voice before generating the rest.
  - Make one file per skit line.
- **Getting audio into the workspace:**
  - Prefer a TTS tool that writes the audio file straight into the workspace.
  - Otherwise download the result URL with curl.
  - If the environment's network blocks the download, do not route around it. Tell the user which host is blocked so they can allow it, or ask them to upload the audio files.
- **Timing:**
  - Measure each file with `ffprobe`.
  - Find sentence boundaries with `ffmpeg -af silencedetect=noise=-35dB:d=0.18 -f null -` and map them to script sentences.
  - Inside a sentence, place word events by character proportion.
  - Build the master timeline: narration chunks with small gaps, and skit lines inserted where the script puts them (shift the following narration).
  - Optionally speed narration by 1.03–1.08× with `atempo` if it drags.
- **Music and SFX:**
  - `build_bed(duration, events, path, mood=..., seed=..., bpm=...)` synthesises an original ambient bed plus SFX (pop, ding, thud, tick, whoosh).
  - Change the mood, seed and bpm per video so no two beds are the same.
  - Put SFX on tags, stamps, coins, cuts and whips.
  - Mix in ffmpeg: voices at 1.0, bed at about 0.5, then `alimiter`.

---

## 8. Rendering and QA

- **Stills first:** render stills at 6–12 moments with `stills()`, make a contact sheet with PIL, and look at it. Fix:
  - text overflowing tags or signs
  - characters cut awkwardly or covered by props
  - labels covering faces
  - empty screen edges during camera moves
  - glyphs the font lacks (draw stars and icons as shapes, not unicode)
- **Render:** `render(scenes, END, out, t_from, t_to)`.
  - It runs at roughly 3× real time per CPU core at 1080p30.
  - For anything over about 1 minute, render each chapter in its own background process (`nproc` at a time) and join them with the ffmpeg concat demuxer.
  - Long renders run in the background; check on them before replying.
- **Mux:** `ffmpeg -i video.mp4 -i final_audio.wav -c:v copy -c:a aac -b:a 192k -shortest out.mp4`.
- **Final QA:** extract frames at every transition and at 6+ random points, and check that mouths move only while each speaker talks. Check facts against your source notes one last time.
- **Deliver:** the MP4 file, the script, the title, the description with chapters and sources, and the thumbnail idea. Say in one line anything that had to be simplified.

---

## 9. Setup

```bash
python3 -m venv .venv && . .venv/bin/activate      # keeps the system Python untouched
pip install -q pycairo numpy pillow
mkdir -p ~/.fonts
curl -sSL -o ~/.fonts/Caveat.ttf "https://raw.githubusercontent.com/google/fonts/main/ofl/caveat/Caveat%5Bwght%5D.ttf"
curl -sSL -o ~/.fonts/PatrickHand.ttf "https://raw.githubusercontent.com/google/fonts/main/ofl/patrickhand/PatrickHand-Regular.ttf"
fc-cache -f; fc-list | grep -i caveat     # must list Caveat
which ffmpeg ffprobe                      # install ffmpeg if missing
```
Then copy `engine.py` (next to this SKILL.md) into the working folder. `examples/smoke_test.py` is a 9-second, three-scene test (an office with a tag, a stamp and a whip pan; a cave with fire and a mammoth and a zoom-through; a typed card) plus a still showing every mood. Run `python3 smoke_test.py stills out_dir` or `python3 smoke_test.py render out.mp4` to check the setup. In each project, write a `video.py` that does `from engine import *`, defines `CAST`, the scene draw functions, the `Scene(...)` list with shot lists, `E.SHAKES`, and calls `stills()` / `render()` / `build_bed()`.

### Minimal scene example (pattern only; build every scene fresh for the story)
```python
import engine as E
from engine import *

def office(c, t, tg):
    cam(c, 0.7)                                    # background layer
    vgrad(c, -400, -300, W + 800, H + 600, rgb('#2a3b5c'), rgb('#141c30'))
    city_windows(c, 1200, 120, 520, 360, seed=2)
    cam(c, 1.0)                                    # main layer
    c.rectangle(-400, 700, W + 800, 600); fill(c, rgb('#2c2a3a'))
    glow(c, 900, 500, 600, rgb('#ffcf87'), 0.25)
    person(c, 900, 1000, 1.25, jacket='#1f2433', tie='#c8312c', glasses=True,
           mouth=talking(tg, (3.1, 4.0)), blink=blinking(tg, 0.7))
    label_tag(c, 1150, 420, '$1', back((tg - 2.4) / 0.45))
    dust(c, tg, 500, 150, 900, 500)
    lower_label(c, 'NEW YORK, 1929', ease(t / 0.5) * (1 - smooth((t - 2.5) / 0.4)))
    screen(c); vignette(c, 0.75)

scenes = [Scene('office', 0, 5, office,
                [(0, 2.2, (960, 540, 1.1), (1000, 530, 1.16), smooth),          # wide
                 (2.2, 4.4, (1120, 440, 1.8), (1140, 430, 1.9), smooth),        # push on tag
                 zoom_shot(4.4, 5.0, (1150, 420, 1.9))], exit='zoom')]
E.SHAKES[:] = [(2.4, 7)]
```

---

## 10. Engine reference (`engine.py`)

The engine ships as `engine.py` next to this file; read it when you need details. Main pieces:

| Area | Functions |
|---|---|
| Camera | `cam(c, depth)` before each depth layer, `screen(c)` for screen-space overlays, `E.SHAKES` for impacts |
| Drawing | `rr`, `fs` (fill + ink outline), `fill`, `line`, `poly`, `glow`, `vgrad`, `text`, `text_width`, `star`, `vignette` |
| Characters | `person(...)` (styles, hats, beards, robes, moods, props), `animal(kind=...)`, `talking(t, span)`, `blinking(t, seed)` |
| Props and graphics | `label_tag`, `calendar`, `wall_clock`, `coin`, `stamp`, `document`, `bar_chart`, `lower_label`, `typed_card`, `title_card` |
| Ambient motion | `dust`, `steam`, `rain`, `snow`, `fire`, `flicker`, `city_windows` |
| Timeline | `Scene(name, start, end, draw, shots, enter, exit)`, `whip_shot`, `zoom_shot`, `stills`, `render` |
| Sound | `build_bed(duration, events, path, mood, seed, bpm)` (pad changes chord every 8 beats and loops), `sfx_pop/ding/thud/tick/whoosh` |

Moods: `neutral`, `happy`, `worried` (inner brows up), `angry` (inner brows down), `shocked`.
