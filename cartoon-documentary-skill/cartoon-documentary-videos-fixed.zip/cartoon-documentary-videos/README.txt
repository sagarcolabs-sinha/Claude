CARTOON DOCUMENTARY VIDEOS - Claude skill
==========================================
Makes fully animated 2D cartoon documentary videos
on any topic: finance, history, World War, ancient humans, animals, science...
Script + characters + scenes + voice + editing + render, all done by Claude in code.

HOW TO INSTALL
1. Download this zip (don't unzip it).
2. In Claude, open your Skills settings and upload the zip as a new skill.
3. Start a new chat and type something like:
   "Make a 10-minute cartoon documentary video titled: How Rome Fed One Million People"

WHAT'S INSIDE
- SKILL.md ............ the full instructions (script method, style, editing, voice, rendering)
- engine.py ........... the drawing + animation engine
- examples/smoke_test.py  a 9-second three-scene test of the whole pipeline

NOTES
- Voiceover uses a text-to-speech tool (for example ElevenLabs) if one is connected.
- Every script is written fresh from new research with a randomly rolled
  structure, so scripts vary a lot between videos (it can't see other people's
  scripts, so it can't guarantee no overlap).
