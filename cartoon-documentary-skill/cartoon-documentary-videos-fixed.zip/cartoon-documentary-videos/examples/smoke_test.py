"""Three-scene smoke test for the cartoon-documentary engine: office (tag, stamp, whip out),
cave (fire, mammoth, zoom out), typed text card (fade in). Also shows every mood side by side."""
import sys, time, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))  # find engine.py one level up
import engine as E
from engine import *


def office(c, t, tg):
    cam(c, 0.7)
    vgrad(c, -400, -300, W + 800, H + 600, rgb('#2a3b5c'), rgb('#141c30'))
    city_windows(c, 1200, 120, 520, 360, seed=2)
    cam(c, 1.0)
    c.rectangle(-400, 700, W + 800, 600); fill(c, rgb('#2c2a3a'))
    glow(c, 900, 500, 600, rgb('#ffcf87'), 0.25)
    wall_clock(c, 400, 300, 70, 9.25)
    calendar(c, 1600, 330, 'OCT', '1929', 0.9)
    person(c, 900, 1000, 1.25, jacket='#1f2433', tie='#c8312c', glasses=True,
           mouth=talking(tg, (1.0, 2.2)), blink=blinking(tg, 0.7), mood='worried')
    person(c, 1350, 1000, 1.1, shirt='#7a4a2a', style='curly', hair='#3a2a1a', hat='cowboy',
           armR=2.6, mood='angry', flip=True)
    label_tag(c, 1150, 420, '$1', back((tg - 2.4) / 0.45))
    stamp(c, 600, 520, 'CRASH', (tg - 3.2) / 0.25)
    dust(c, tg, 500, 150, 900, 500)
    lower_label(c, 'NEW YORK, 1929', ease(t / 0.5) * (1 - smooth((t - 2.5) / 0.4)))
    screen(c); vignette(c, 0.75)


def cave(c, t, tg):
    cam(c, 0.7); vgrad(c, -400, -300, W + 800, H + 600, rgb('#3a2418'), rgb('#120a06'))
    cam(c, 1.0); c.rectangle(-400, 760, W + 800, 600); fill(c, rgb('#2a1a10'))
    fire(c, t, 960, 820, 1.0)
    person(c, 600, 980, 1.1, robe='#7a5a3a', style='wild', beard='full', hair='#4a3020', mood='happy')
    animal(c, 1400, 980, 0.8, kind='mammoth', col='#6a4a32', walk=1)
    screen(c); vignette(c, 0.8)


def card(c, t, tg):
    typed_card(c, t, [('Forty billion dollars. Gone in a day.', 0.1, 1.4, 520, 90),
                      ('That is the story.', 1.6, 2.3, 640, 80, rgb('#f4d35e'))])


def moods(c, t, tg):
    """all five moods side by side, to check the brows"""
    cam(c, 1.0); vgrad(c, -400, -300, W + 800, H + 600, rgb('#e9e2d0'), rgb('#cfc4ab'))
    for i, m in enumerate(['neutral', 'happy', 'worried', 'angry', 'shocked']):
        x = 230 + i * 365
        person(c, x, 900, 1.3, mood=m)
        text(c, m, x, 1010, 64, INK)


scenes = [Scene('office', 0, 4.0, office,
                [(0, 2.2, (960, 540, 1.0), (1000, 530, 1.06), smooth),
                 (2.2, 3.6, (1100, 460, 1.5), (1120, 450, 1.6), smooth),
                 whip_shot(3.6, 4.0, (1120, 450, 1.6))], exit='whip'),
          Scene('cave', 4.0, 6.5, cave, [(4.0, 6.5, (960, 600, 1.0), (980, 620, 1.08), smooth)], exit='zoom'),
          Scene('card', 6.5, 9.0, card, [], enter='fade')]
E.SHAKES[:] = [(2.4, 7), (3.2, 25)]
END = 9.0

if __name__ == '__main__':
    mode, out = sys.argv[1], sys.argv[2]
    if mode == 'stills':
        print(stills(scenes, END, [1.5, 3.4, 3.9, 4.05, 5.5, 8.5], out + '/s_{:05.2f}.png'))
        print(stills([Scene('moods', 0, 1, moods, [(0, 1, (960, 540, 1.0), (960, 540, 1.0), smooth)])], 1,
                     [0.5], out + '/moods_{:05.2f}.png'))
    else:
        t = time.time(); render(scenes, END, out)
        print('render', round(time.time() - t, 1), 's for', END, 's of video')
        build_bed(END, [(2.4, 'pop', 1), (3.2, 'thud', 1), (3.7, 'whoosh', 1)], out + '.wav', mood='tense', seed=3)
